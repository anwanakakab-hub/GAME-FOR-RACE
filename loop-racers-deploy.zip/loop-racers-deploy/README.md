# Loop Racers 2.0

## Local run
Requires Node.js 20+. Run `npm start`, then open http://localhost:3000.

## Deployment to Render
Push this folder to GitHub, then in Render choose New > Blueprint and select the repository containing `render.yaml`.
Alternatively choose New > Web Service; runtime Node, build `npm install`, start `npm start`.
The server honors Render's `PORT` environment variable.

## Current prototype limitations
Rooms are stored in server memory: they disappear on restart or sleep, and are not shared across multiple server instances. Use a single instance.
This is an early prototype, not a verified production multiplayer service.
